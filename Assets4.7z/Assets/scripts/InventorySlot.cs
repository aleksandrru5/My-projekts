using System.Collections;
using UnityEngine;

public class InventorySlot
{
    public Vector2Int position;
    public int quantity;
    public ItemClass item;
}
